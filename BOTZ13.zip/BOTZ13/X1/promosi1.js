const promosi1 = () => { 
	return `[ YOUR_IKLAN ]`
}
exports.promosi1 = promosi1