const promosi2 = () => { 
	return `[ YOUR_IKLAN ]`
}
exports.promosi2 = promosi2