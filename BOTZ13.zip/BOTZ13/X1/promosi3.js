const promosi3 = () => { 
	return `[ YOUR IKLAN ]`
}
exports.promosi3 = promosi3